
package boleto.configuraMulta;


public class CaixaMulta implements Multa {

    @Override
    public double getMulta() {
        return 0.05;
    }    
}
