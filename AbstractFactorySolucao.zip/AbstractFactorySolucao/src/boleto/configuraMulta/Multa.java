
package boleto.configuraMulta;


public interface Multa {
    public double getMulta();
}
