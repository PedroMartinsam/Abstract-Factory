
package boleto.configuraMulta;


public class BBMulta implements Multa {

    @Override
    public double getMulta() {
        return 0.02;
    }
    
}
