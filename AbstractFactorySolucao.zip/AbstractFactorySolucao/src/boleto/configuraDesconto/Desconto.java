
package boleto.configuraDesconto;


public interface Desconto {
    public double getDesconto();
}
