
package boleto.configuraDesconto;


public class CaixaDesconto implements Desconto{

    @Override
    public double getDesconto() {
           return 0.1;
    }
}
