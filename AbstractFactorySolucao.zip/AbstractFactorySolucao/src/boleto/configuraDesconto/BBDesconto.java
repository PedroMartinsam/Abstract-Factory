
package boleto.configuraDesconto;


public class BBDesconto implements Desconto{

    @Override
    public double getDesconto() {
return 0.05;
    }
    
}
