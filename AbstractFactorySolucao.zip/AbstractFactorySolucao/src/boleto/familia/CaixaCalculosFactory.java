
package boleto.familia;

import boleto.configuraDesconto.CaixaDesconto;
import boleto.configuraDesconto.Desconto;
import boleto.configuraJuros.CaixaJuros;
import boleto.configuraJuros.Juros;
import boleto.configuraMulta.CaixaMulta;
import boleto.configuraMulta.Multa;


public class CaixaCalculosFactory implements CalculosFactory {

    @Override
    public Juros criarJuros() {
        return new CaixaJuros();
    }

    @Override
    public Desconto criarDesconto() {
        return new CaixaDesconto();
    }

    @Override
    public Multa criarMulta() {
        return new CaixaMulta();
    }
    
}
