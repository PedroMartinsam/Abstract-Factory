
package boleto.configuraJuros;


public interface Juros {
    public double getJuros();
}
