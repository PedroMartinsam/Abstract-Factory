
package boleto.configuraJuros;


public class BBJuros implements Juros{

    @Override
    public double getJuros() {
        return 0.03;
        }
    
}
