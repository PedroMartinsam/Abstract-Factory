
package boleto.configuraJuros;


public class CaixaJuros implements Juros {

    @Override
    public double getJuros() {
        return 0.02;
    }
    
}
