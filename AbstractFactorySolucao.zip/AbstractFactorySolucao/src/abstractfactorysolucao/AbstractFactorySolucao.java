
package abstractfactorysolucao;

import boleto.familia.BBCalculosFactory;
import boleto.familia.CaixaCalculosFactory;
import boleto.familia.CalculosFactory;
import boletoo.Banco;


public class AbstractFactorySolucao {
    public static void main(String[] args) {
        
       Banco banco = new Banco();
       
       CalculosFactory factoryCaixa = new CaixaCalculosFactory();
       CalculosFactory factoryBB= new BBCalculosFactory();
       
        System.out.println("cria boleto caixa");
        banco.gerarBoleto(100, factoryCaixa);
        
        System.out.println("cria boleto BB");
        banco.gerarBoleto(100, factoryBB);   
    }
    
}
